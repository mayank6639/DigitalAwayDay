/**
 * 
 */
package com.digital.away.day.utilities;

/**
 * @author mayank gupta
 * This class contains constant used in the application
 *
 */
public interface DigitalAwayDayConstants {
	
	String FILE_INPUT_PATH="file.input.path";
	String FILE_NAME="file.input.fileName";
	String FILE_OUTPUT_PATH="file.output.path";
	String OUTPUT_FILE_NAME="file.out.fileName";
	
	String TIME_SPRINT="time.sprint";
	String TEAM_NAME_FIRST="team.name.first";
	String TEAM_NAME_SECOND="team.name.second";
	String STAFF_PRESENTATION_ACTIVITY="Staff.presentation.name";
	
	String CONFIGURATIONFILE_PATH="DeloitteDigitalAwayDay/";
	String CONFIGURATIONFILE_NAME="configuration.properties";
	String INPUT_FILE="DigitalAwayDay.txt";
	int TOTALMORNING = 180;
	int TOTALEVENING = 240;
	int SIXTY_MINUTES=60;
	String MINUTES="min";
	
	String EXCEPTION_FILE_EXPORT="Error while Exporting the File";
	
	String NEXT_LINE="\n";
	String START_TIME="09:00";
	String LUNCH_TIME="12:00";
	String TIMINGS_FORMAT="hh:mm a";
	String SPRINT="sprint";
	String LUNCH_BREAK="Lunch Break 60min";
	String COLON=" : ";
	

}
