/**
* 
 */
package com.digital.away.day.serviceImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.digital.away.day.service.DigitalAwayDayService;
import com.digital.away.day.utilities.DigitalAwayDayConstants;
import com.digital.away.day.utilities.DigitalAwayDayUtility;

/**
* @author Mayank Gupta
* This Service Layer class handles the controller calls and return 
 * || evaluate the data based on the timings of presentation.
*
*/
public class DigitalAwayDayServiceImpl implements DigitalAwayDayService,DigitalAwayDayConstants { 
              Map<String,String> properties = null;
              public DigitalAwayDayServiceImpl(){
                             // Load property File In-Memory
                             properties = DigitalAwayDayUtility.loadProperties();
              }

              /***
              * @author mayank gupta
              * @param Integer
              * @param List<List<Integer>>
              * @throws Exception
              * This method evaluates the best Slot time 9 AM to 12 PM || 1 PM to 4 PM
              * & return the best the best slot for the presentation.
              */
              @Override
              public  Integer bestSlot(Integer presentationMinutes, List<List<Integer>> stack) throws Exception{
                             List<Integer> bestSlot=null;
                             int totalSlots = 2;
                             
                             try {
                                           int least = DigitalAwayDayUtility.sumOfSlots(stack.get(0));

                                           if(least+presentationMinutes <= TOTALEVENING)
                                                          bestSlot=stack.get(0);
                                           if(DigitalAwayDayUtility.sumOfSlots(stack.get(1)) < least 
                                                                        && DigitalAwayDayUtility.sumOfSlots(stack.get(1)) + presentationMinutes <=  TOTALEVENING){
                                                          least = DigitalAwayDayUtility.sumOfSlots(stack.get(1));
                                                          bestSlot = stack.get(1);
                                           }
                                           if(bestSlot==null)
                                                          totalSlots=4;
                                           if(totalSlots > 2){
                                                          if(DigitalAwayDayUtility.sumOfSlots(stack.get(2)) + presentationMinutes <=  TOTALMORNING){
                                                                        least = DigitalAwayDayUtility.sumOfSlots(stack.get(2));
                                                                        bestSlot = stack.get(2);
                                                          }
                                                          if(DigitalAwayDayUtility.sumOfSlots(stack.get(3)) + presentationMinutes <= TOTALMORNING){
                                                                        least = DigitalAwayDayUtility.sumOfSlots(stack.get(3));
                                                                        bestSlot = stack.get(3);
                                                          }
                                           }
                             } catch (Exception e) {
                                           throw new Exception("Error while bestSlotByTime" + e);
                             }
                             return stack.indexOf(bestSlot);
              }
              
              /**
              * @author mayank gupta
              * @param List<String>
              * @param List<List<Integer>>
              * This method triggers the printing format based on the slot selected by bestSlotByTime()
              * & return the String with output formatted.
              */
              @Override
              public StringBuilder arrangeActivity(List<String> activities, List<List<Integer>> slotArrangement)
                                           throws Exception {
                             StringBuilder digitalAwayDayarrangements = new StringBuilder(); 

                             try {
                             digitalAwayDayarrangements.append(NEXT_LINE+properties.get(TEAM_NAME_FIRST)+NEXT_LINE);
                                           activities = printActivities(activities, slotArrangement, digitalAwayDayarrangements, 2);

                             digitalAwayDayarrangements.append(NEXT_LINE+properties.get(TEAM_NAME_SECOND)+NEXT_LINE);
                                           printActivities(activities, slotArrangement, digitalAwayDayarrangements, 3);
                             } catch (Exception e) {
                                           throw new Exception("Error while arrangeActivityBySlot" + e);
                             }
                             return digitalAwayDayarrangements;
              }
              /**
              * @author mayank gupta
              * @param activities
              * @param slotArrangement
              * @param arrangements
              * @param index
              * This method iterate over the slots and return the output with formated timings
              */
              private List<String> printActivities(List<String> activities, List<List<Integer>> slotArrangement
                                           ,StringBuilder arrangements, int index) throws Exception{

                             LocalTime sixThirty = LocalTime.parse(START_TIME);
                             LocalTime noon = LocalTime.parse(LUNCH_TIME);

                             try {
                                           DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(TIMINGS_FORMAT);
                                           int startTime = 0;
                                           for(; index >= 0; index=index-2){
                                                          // If timings have gap before lunch, Start the first presentation after Gap minutes
                                                          if(index == 2 || index == 3){
                                                                        startTime =  DigitalAwayDayConstants.TOTALMORNING - DigitalAwayDayUtility.sumOfSlots(slotArrangement.get(index));
                                                                        sixThirty = sixThirty.plusMinutes(startTime); 
                                                          }

                                                          for(Integer value : slotArrangement.get(index)){ 
                                                                        activities = activities.stream().map(x -> x.replaceAll(SPRINT, properties.get(TIME_SPRINT)))
                                                                                                    .collect(Collectors.toList());
                                                                        String activityName = activities.stream().filter(p -> p.contains(value+MINUTES)).findFirst().get();
                                                                        int indexOfActivity = activities.indexOf(activityName);
                                                                        if(noon.equals(sixThirty)){
                                                                                      arrangements.append(sixThirty.format(dateFormat));
                                                                                      arrangements.append(" : ");
                                                                                      arrangements.append(LUNCH_BREAK+NEXT_LINE);
                                                                                      sixThirty = sixThirty.plusMinutes(SIXTY_MINUTES); 
                                                                        }
                                                                        arrangements.append(sixThirty.format(dateFormat));
                                                                        arrangements.append(" : ");
                                                               arrangements.append(activityName.contains(properties.get(TIME_SPRINT))
                                                                                                     ?activityName.replaceAll(properties.get(TIME_SPRINT), SPRINT):activityName);
                                                                        arrangements.append(NEXT_LINE);
                                                                        activities.remove(indexOfActivity);
                                                                        sixThirty = sixThirty.plusMinutes(value); 

                                                          }
                                           }
                                           arrangements.append(sixThirty.format(dateFormat));
                                           arrangements.append(COLON);
                                           arrangements.append(properties.get(STAFF_PRESENTATION_ACTIVITY));
                                           arrangements.append(NEXT_LINE);
                             } catch (Exception e) {
                                           throw new Exception("Error while printActivity" + e);
                             }
                             return activities;
              }

              /**
              * @author mayank gupta
              * @exception FileNotFoundException
              * This method read the input file from the System Directory and prepare the LIST
              * @throws URISyntaxException 
               */
              @Override
              public List<String> readFile() throws FileNotFoundException,IOException, URISyntaxException { 
                             List<String> activity = new ArrayList<>();

                             InputStream input =DigitalAwayDayUtility.class.getClassLoader().getResourceAsStream(properties.get(FILE_NAME));
                             
                             try (BufferedReader buffer = new BufferedReader(new InputStreamReader(input))) {
                                           activity = buffer.lines().collect(Collectors.toList());
                   } catch (FileNotFoundException e) {
                                           throw new IOException("Error FileNotFoundException while readInputFile" + e);
                             }catch (IOException e) {
                                           throw new IOException("Error IOException while readInputFile " + e);
                             }
                             return activity;
              }

              /**
              * @author mayank gupta
              * @param data
              * @exception IOException
              * This method write the file with all the presentation slots with timings.
              * 
               */
              @Override
              public boolean writeOutput(String data) throws IOException {
                             boolean exported = false;
                             try{
                                           new File(properties.get(FILE_OUTPUT_PATH)).mkdirs();
                                           Files.write(Paths.get(properties.get(FILE_OUTPUT_PATH)
                                                                        +properties.get(DigitalAwayDayConstants.OUTPUT_FILE_NAME)), data.getBytes());
                                           exported = true;
                             }catch(IOException ioException){
                                           throw new IOException(EXCEPTION_FILE_EXPORT);
                             }

                             return exported;
              }

}
