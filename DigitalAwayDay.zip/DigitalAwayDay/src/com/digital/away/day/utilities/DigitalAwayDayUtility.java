/**
 * 
 */
package com.digital.away.day.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

/**
 * @author mayank gupta
 * This class is Utility class contains all the utility methods of Application.
 * loadProperties
 * shuffleActivityByTimeSlot
 * initalizeStack
 * getTimeByActivityList
 * shuffleAndSortActivity
 * sumOfSlots
 * 
 *
 */
public class DigitalAwayDayUtility implements DigitalAwayDayConstants{

	static Map<String,String> properties = new HashMap<>();
	
	/**
	 * 
	 * @return Map<String,String> : properties
	 * This method load the property from the property file and prepare the KEY:VALUE Data
	 */
	public static Map<String,String> loadProperties(){
		Properties prop = new Properties();
		try {
			if(properties.size() == 0){
			/*	ClassLoader classLoader = new ActivityUtility().getClass().getClassLoader();
				File file = new File(classLoader.getResource(CONFIGURATIONFILE_NAME).getFile());*/
				
				try(InputStream input =DigitalAwayDayUtility.class.getClassLoader().getResourceAsStream(CONFIGURATIONFILE_NAME)){
					prop.load(input);
					properties.put(FILE_INPUT_PATH, prop.getProperty(FILE_INPUT_PATH));
					properties.put(FILE_NAME, prop.getProperty(FILE_NAME));
					properties.put(FILE_OUTPUT_PATH, prop.getProperty(FILE_OUTPUT_PATH));
					properties.put(OUTPUT_FILE_NAME, prop.getProperty(OUTPUT_FILE_NAME));
					properties.put(OUTPUT_FILE_NAME, prop.getProperty(OUTPUT_FILE_NAME));
					properties.put(TIME_SPRINT, prop.getProperty(TIME_SPRINT));
					properties.put(TEAM_NAME_FIRST, prop.getProperty(TEAM_NAME_FIRST));
					properties.put(TEAM_NAME_SECOND, prop.getProperty(TEAM_NAME_SECOND));
					properties.put(STAFF_PRESENTATION_ACTIVITY, prop.getProperty(STAFF_PRESENTATION_ACTIVITY));
				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return properties;
	}

	/**
	 * @author mayank gupta
	 * @param activity
	 * @return shuffle
	 * This method shuffle the timings and sort it in DESC order and prepare the LIST
	 */
	public static List<String> shuffleActivityByTimeSlot(List<String> activity) {
		List<String> shuffle = new ArrayList<>();
		for (String timing : activity) {
			String lastWord = timing.substring(timing.lastIndexOf(' ') + 1);
			timing = timing.replaceAll(lastWord, "").trim();
			timing = lastWord + " " + timing;
			timing = timing.replaceAll(SPRINT, properties.get(TIME_SPRINT)).trim();
			shuffle.add(timing);
		}
		return shuffle;

	}
	/**
	 * @author mayank gupta
	 * @param listOfSlots
	 * Initialize the slots of list objects 
	 */
	public static void initalizeStack(List<List<Integer>> listOfSlots) {
		List<Integer> Q912Q1 = new ArrayList<>();
		List<Integer> Q912Q2 = new ArrayList<>();
		List<Integer> Q15Q1 = new ArrayList<>();
		List<Integer> Q15Q2 = new ArrayList<>();
		listOfSlots.add(Q15Q1);
		listOfSlots.add(Q15Q2);
		listOfSlots.add(Q912Q1);
		listOfSlots.add(Q912Q2);
	}
	/**
	 * @author mayank gupta
	 * @param activityWithTime
	 * @return Integer
	 * Returns the timings from the Activity Name
	 */
	public static Integer getTimeByActivityList(String activityWithTime) {
		StringTokenizer token = new StringTokenizer(activityWithTime, MINUTES);
		return Integer.valueOf(token.nextToken());
	}
	/**
	 * @author mayank gupta
	 * @param activity
	 * @return activityNameShuffle
	 * This method shuffle the timings and sort it in DESC order and prepare the LIST
	 */
	public static List<String>  shuffleAndSortActivity(List<String> activity){
		List<String> activityNameShuffle = new ArrayList<>();
		activityNameShuffle = DigitalAwayDayUtility.shuffleActivityByTimeSlot(activity);
		activityNameShuffle.sort((e1, e2) -> e2.compareTo(e1));

		return activityNameShuffle;
	}
	/**
	 * @author mayank gupta
	 * @param listValuesOfSlot
	 * @return sum
	 * This method returns the sum of all the timings from the specific slot to evaluate the best Slot for the presentation.
	 */
	public static Integer sumOfSlots(List<Integer> listValuesOfSlot){
		Integer sum = listValuesOfSlot.stream().collect(Collectors.summingInt(Integer::intValue));
		return sum;
	}

}
